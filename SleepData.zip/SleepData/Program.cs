﻿using System;
using System.IO;
using System.Linq;

namespace SleepData
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            // ask for input
            Console.WriteLine("Enter 1 to create data file.");
            Console.WriteLine("Enter 2 to parse data.");
            Console.WriteLine("Enter anything else to quit.");
            // input response
            string resp = Console.ReadLine();

			// specify path for data file
			// string file = "/users/jgrissom/downloads/data.txt";
            // the one below uses current location
			string file = AppDomain.CurrentDomain.BaseDirectory + "data.txt";

            if (resp == "1")
            {
                // create data file

                // ask a question
                Console.WriteLine("How many weeks of data is needed?");
                // input the response (convert to int)
                int weeks = int.Parse(Console.ReadLine());

                // determine start and end date
                DateTime today = DateTime.Now;
                // we want full weeks sunday - saturday
                DateTime dataEndDate = today.AddDays(-(int)today.DayOfWeek);
                // subtract # of weeks from endDate to get startDate
                DateTime dataDate = dataEndDate.AddDays(-(weeks * 7));

                // random number generator
                Random rnd = new Random();

                // create file
                StreamWriter sw = new StreamWriter(file);
                // loop for the desired # of weeks
                while (dataDate < dataEndDate)
                {
                    // 7 days in a week
                    int[] hours = new int[7];
                    for (int i = 0; i < hours.Length; i++)
                    {
                        // generate random number of hours slept between 4-12 (inclusive)
                        hours[i] = rnd.Next(4, 13);
                    }
                    // M/d/yyyy,#|#|#|#|#|#|#
                    //Console.WriteLine($"{dataDate:M/d/yy},{string.Join("|", hours)}");
                    sw.WriteLine($"{dataDate:M/d/yyyy},{string.Join("|", hours)}");
                    // add 1 week to date
                    dataDate = dataDate.AddDays(7);
                }
                sw.Close();
            }
            else if (resp == "2")
            {
                // TODO: parse data file

                var date = DateTime.Now;



               //Console.WriteLine("Week of " + date.ToString("MMM dd, yyyy"), date);
                //Console.WriteLine(String.Format("{0,4}", date.ToString("ddd")));
                //Console.WriteLine(" --");

                if (File.Exists(file))
                {
                 
                    // read data from file
                    StreamReader sr = new StreamReader(file);
                    while (!sr.EndOfStream)
                    {

                        string line = sr.ReadLine();

                        // convert string to array // also split on comma
                        string[] arr = line.Split('|', ',');
                        string[] arr2 = line.Split('|', ',');

                        var arr0 = arr[0];
                        DateTime date1 = Convert.ToDateTime(arr0);

                        // convert string to int
                        int parseNumber1 = int.Parse(arr2[1]);
                        int parseNumber2 = int.Parse(arr2[2]);
                        int parseNumber3 = int.Parse(arr2[3]);
                        int parseNumber4 = int.Parse(arr2[4]);
                        int parseNumber5 = int.Parse(arr2[5]);
                        int parseNumber6 = int.Parse(arr2[6]);
                        int parseNumber7 = int.Parse(arr2[7]);

                        // calculate sum of ints
                        int sum = parseNumber1 + parseNumber2 + parseNumber3 + parseNumber4 +
                                     parseNumber5 + parseNumber6 + parseNumber7;

                        double[] numbers = {parseNumber1, parseNumber2, parseNumber3, parseNumber4, 
                                     parseNumber5, parseNumber6,parseNumber7};

                        // calculate avg of ints
                        double avg = (sum / 7);

                        // display array data
                        Console.WriteLine("Week of " + date1.ToString("MMM dd, yyyy"), arr0);

                        Console.WriteLine("{0,4}{1,4}{2,4}{3,4}{4,4}{5,4}{6,4}{7,4}{8,4}", "Su", "Mo", "Tu", "We", "Th", "Fr", "Sa", "Tot", "Avg");

                        Console.WriteLine("{0,4}{1,4}{2,4}{3,4}{4,4}{5,4}{6,4}{7,4}{8,4}", "--", "--", "--", "--", "--", "--", "--", "--", "--");

                        Console.WriteLine("{0,4}{1,4}{2,4}{3,4}{4,4}{5,4}{6,4}{7,4}{8,4}", arr[1], arr[2], arr[3], arr[4], arr[5], arr[6], arr[7], sum, avg);

                        // TRIED AND FAILED CODE
                        //string[] sumOfDays = {arr2[1], arr2[2], arr2[3], arr2[4], arr2[5], arr2[6], arr2[7]};

                        //arr3 = Int32.TryParse(arr2[1]);
                        //double sum = sumOfDays.Sum();

                        //int[] myInts = Array.ConvertAll(sumOfDays, int.Parse);

                    }

                }
                else
                {
                    Console.WriteLine("File does not exist");
                }

            }
        }
    }
}


/*
 * // ------------- strings ------------- //

String name = "Brie";
String address = "wctc";

// these two lines produce the same results
Console.WriteLine("{0}{1}", name, address);
            Console.WriteLine($"{name} {address}");

            Console.WriteLine(String.Format("{0,-8}{1,12}", "name", "Salary"));
            Console.WriteLine(String.Format("{0,-8}{1,12:C2}", "Jeff", "25000"));
            Console.WriteLine(String.Format("{0,-8}{1,12:C2}", "Lisa", "35000"));

            // {0, 10} -- 0 is position, 10 is number of character width
            // By default, characters are left-aligned
            // Use a negative {0, -10} to right-align
            Console.WriteLine(String.Format("{0,-8}{1,1}", "Name", "Address"));
            Console.WriteLine(String.Format("{0,-8}{1,12}", "Name", "Address"));
            Console.WriteLine(String.Format("{0,8}{1,17}", "Name", "Address"));


            // ------------- dates ------------- //

            var date = DateTime.Now;

Console.WriteLine(date.ToString());

            // "d" -- The day of the month, from 1 through 31
            Console.WriteLine(date.ToString("d"));

            // "dd" -- The day of the month, from 01 through 31
            Console.WriteLine(date.ToString("dd"), date);

            // "ddd" -- The abbreviated name of the day of the week
            Console.WriteLine(date.ToString("ddd"), date);

            // "dddd" -- The full name of the day of the week
            Console.WriteLine("{0:dddd}", date);

     *
     */
